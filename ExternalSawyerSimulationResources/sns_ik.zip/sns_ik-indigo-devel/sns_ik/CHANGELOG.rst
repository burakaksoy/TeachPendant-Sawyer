^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package sns_ik
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.3 (2017-10-29)
------------------
* No Updates

0.2.1 (2016-10-25)
------------------
* No Updates

0.2.0 (2016-09-06)
------------------
* No updates

0.1.1 (2016-04-28)
---------------------------------
* No updates

0.1.0 (2016-04-22)
---------------------------------
* Converts sns lib into package framework
  This commit lays the foundation for a collection of
  SNS IK packages:
  - sns_ik : Metapackage for SNS IK solver, plugins, examples
  - sns_ik_lib: SNS IK solver library
  - sns_ik_examples: Tests and examples for SNS IK library
  - sns_ik_kinematic_plugins: A package for integrating SNS IK with moveit_ros
  Also, added Fabrezio, Ian, and Forrest as authors of these packages.
* Contributors: Ian McMahon
