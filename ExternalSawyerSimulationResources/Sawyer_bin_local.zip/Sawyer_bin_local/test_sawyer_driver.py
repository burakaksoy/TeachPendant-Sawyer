from RobotRaconteur.Client import *
import time
import numpy as np
import yaml


robot = RRN.ConnectService('rr+tcp://127.0.0.1:58653?service=sawyer')


robot.enable()
# robot_state = robot.robot_state.PeekInValue()
# pose=robot_state[0].kin_chain_tcp
# joints=robot_state[0].joint_position
# print(joints)

robot_const = RRN.GetConstants("com.robotraconteur.robotics.robot", robot)
halt_mode = robot_const["RobotCommandMode"]["halt"]
jog_mode = robot_const["RobotCommandMode"]["jog"]
robot.command_mode = halt_mode
robot.command_mode = jog_mode

destination=RRN.GetNamedArrayDType("com.robotraconteur.geometry.Pose",robot)
position=np.zeros((1,),dtype=destination)
position[0]['orientation']['w']=0.5247556244356696
position[0]['orientation']['x']=0.5146317468035063
position[0]['orientation']['y']=-0.48005280088301866
position[0]['orientation']['z']=-0.47888934856548176

def move(p,angle,robot):
	global position
	
	position[0]['position']['x']=p[0]
	position[0]['position']['y']=p[1]
	position[0]['position']['z']=p[2]
	velocity=RRN.GetNamedArrayDType("com.robotraconteur.geometry.SpatialVelocity",robot)
	spatial_velocity=RRN.ArrayToNamedArray(np.zeros(6,dtype=float),velocity)
	robot.jog_cartesian({0:position},{0:spatial_velocity},False,True)	
	
	return



# move([0.4,0,0.2],0,robot)

joint_diff = np.array([1,0,0,0,0,0,0])*np.deg2rad(1)
joint_vel = np.ones((7,))



while (True):
    robot.jog_joint(joint_diff, joint_vel, True, False)
    print(hex(robot.robot_state.PeekInValue()[0].robot_state_flags))
    time.sleep(1)