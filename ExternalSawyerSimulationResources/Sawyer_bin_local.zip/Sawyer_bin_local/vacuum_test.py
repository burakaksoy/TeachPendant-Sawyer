from RobotRaconteur.Client import *
import time
robot = RRN.ConnectService('rr+tcp://127.0.0.1:58653?service=sawyer')
robot.enable()
robot_const = RRN.GetConstants("com.robotraconteur.robotics.robot", robot)
halt_mode = robot_const["RobotCommandMode"]["halt"]
jog_mode = robot_const["RobotCommandMode"]["jog"]
position_mode = robot_const["RobotCommandMode"]["velocity_command"]
robot.command_mode = halt_mode
time.sleep(0.1)


##off 1a:1, 1b:0
##on  1a:0, 1b:1
robot.setf_signal("right_valve_1a",1)
robot.setf_signal("right_valve_1b",0)

# time.sleep(10)

print(robot.getf_signal("right_valve_1b"))
print(robot.getf_signal("right_valve_1a"))