#!/bin/sh

# RR URL: rr+tcp://localhost:58656?service=robot

dotnet GazeboModelRobotRaconteurDriver.dll --gazebo-url=rr+tcp://localhost:11346/?service=GazeboServer --robotraconteur-tcp-port=58656 --robotraconteur-node-name=staubli_robot --model-name=staubli --robot-info-file=staubli_robot_default_config.yml
