#!/bin/sh

# RR URL: rr+tcp://localhost:58655?service=robot

dotnet GazeboModelRobotRaconteurDriver.dll --gazebo-url=rr+tcp://localhost:11346/?service=GazeboServer --robotraconteur-tcp-port=58655 --robotraconteur-node-name=abb_robot  --model-name=abb --robot-info-file=abb_robot_default_config.yml
