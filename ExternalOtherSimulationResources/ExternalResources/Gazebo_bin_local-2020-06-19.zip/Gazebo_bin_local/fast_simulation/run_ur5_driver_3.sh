#!/bin/sh

# RR URL: rr+tcp://localhost:58653?service=robot

dotnet ../GazeboModelRobotRaconteurDriver.dll --gazebo-url=rr+tcp://localhost:11346/?service=GazeboServer --robotraconteur-tcp-port=55557 --robotraconteur-node-name=ur5_robot_3 --model-name=UR3 --robot-info-file=ur5_robot_default_config_3.yml
