#!/bin/sh

# RR URL: rr+tcp://localhost:58655?service=robot

dotnet ../GazeboModelRobotRaconteurDriver.dll --gazebo-url=rr+tcp://localhost:11346/?service=GazeboServer --robotraconteur-tcp-port=11111 --robotraconteur-node-name=abb_robot_1  --model-name=ABB1 --robot-info-file=abb_robot_default_config_1.yml
