#!/bin/sh

# RR URL: rr+tcp://localhost:58654?service=robot

dotnet GazeboModelRobotRaconteurDriver.dll --gazebo-url=rr+tcp://localhost:11346/?service=GazeboServer --robotraconteur-tcp-port=58654 --robotraconteur-node-name=sawyer_robot  --model-name=sawyer --robot-info-file=sawyer_robot_default_config.yml