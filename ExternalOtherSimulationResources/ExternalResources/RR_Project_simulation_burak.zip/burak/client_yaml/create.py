import yaml
dict_file = {"robot_name":"sawyer","planner name":"plan_Sawyer","gripper_name":"sawyergripper","height_offset":0.15,"Rd":[[ 0., 0., -1. ],
	 [ 0., -1.,  0.],
	 [-1.,  0., 0.]],"obj_namelists":['bottle'],"obj_slot_idx":3,"slot_name":'b_f'}

with open(r'client_Sawyer.yaml', 'w') as file:
    documents = yaml.dump(dict_file, file)