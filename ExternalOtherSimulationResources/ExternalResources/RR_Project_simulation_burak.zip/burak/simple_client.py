#!/usr/bin/env python3

#Simple example Robot Raconteur Sawyer Robot and Cognex client
#pick up and drop detected objects
import RobotRaconteur as RR
RRN=RR.RobotRaconteurNode.s
import numpy as np
import time
import traceback
import copy
import yaml
import sys
sys.path.append('../../')
from vel_emulate import EmulatedVelocityControl
from jog_joint import jog_joint
sys.path.append('../../toolbox')
from abb_ik import abb_inv as inv
#sys.path.append('QP_planner')
#from plan_ABB import plan

with RR.ClientNodeSetup(argv=sys.argv):

	####################Start Service and robot setup
	###########Connect to corresponding services
	cognex_inst=RRN.ConnectService('rr+tcp://localhost:52222/?service=cognexsim',"cats",{"password":RR.RobotRaconteurVarValue("cats111!","string")},None,None)
	robot = RRN.ConnectService('rr+tcp://localhost:58655?service=robot')	#ABB
	vacuum_inst=RRN.ConnectService('rr+tcp://localhost:50000/?service=vacuumlink') 



	##########Initialize robot constants
	robot_const = RRN.GetConstants("com.robotraconteur.robotics.robot", robot)
	halt_mode = robot_const["RobotCommandMode"]["halt"]
	position_mode = robot_const["RobotCommandMode"]["position_command"]
	robot.command_mode = halt_mode

	##########Initialize velocity control parameters
	cmd_w = robot.position_command.Connect()
	state_w = robot.robot_state.Connect()
	RobotJointCommand = RRN.GetStructureType("com.robotraconteur.robotics.robot.RobotJointCommand",robot)
	vel_ctrl = EmulatedVelocityControl(robot,state_w, cmd_w, 0.01)
	robot.command_mode = position_mode 

	

	##########Initialize robot parameters
	robot_name="abb"
	gripper_name="abbgripper"
	home=np.array([0.3,0.0,0.3])
	Rd=np.array([[0,0,1],[0,1,0],[-1,0,0]])
	height_offset=0.21

	num_joints=len(robot.robot_info.joint_info)
	P=np.array(robot.robot_info.chains[0].P.tolist())
	length=np.linalg.norm(P[2])+np.linalg.norm(P[3])+np.linalg.norm(P[4])


	##########load homogeneous transformation parameters Cognex->robot
	obj_namelists=['perfume']
	obj_slot_idx=0
	slot_name="p_f"

	def H42H3(H):
		H3=np.linalg.inv(H[:2,:2])
		H3=np.hstack((H3,-np.dot(H3,np.array([[H[0][-1]],[H[1][-1]]]))))
		H3=np.vstack((H3,np.array([0,0,1])))
		return H3

	with open('calibration/ABB.yaml') as file:
		H_ABB 	= np.array(yaml.load(file)['H'],dtype=np.float64)
	H=H42H3(H_ABB)
	
	def R_ee(angle):
		R=np.array([[0, -np.sin(angle),np.cos(angle)],
				[0, np.cos(angle), np.sin(angle)],
				[-1,0,0]])
		return R



	def angle_threshold(angle):
		if (angle<-np.pi):
			angle+=2*np.pi
		elif (angle>np.pi):
			angle-=2*np.pi
		return angle


	def pick(p,robot,model_name,angle=0):
		angle=np.radians(angle)
		try:
	  
			R=R_ee(angle_threshold(angle))
			

			q=inv(R,np.array([p[0],p[1],p[2]]))

			jog_joint(robot,vel_ctrl,q,1)
			print("get it")
			vacuum_inst.vacuum(robot_name+"::"+gripper_name,model_name,1)
			q=inv(R,np.array([p[0],p[1],p[2]+0.1]))
			jog_joint(robot,vel_ctrl,q,1)

		except:
			traceback.print_exc()
		return
	def place(p,robot,model_name,box_idx,angle=0):
		angle=np.radians(angle)

		try:

	  
			R=R_ee(angle_threshold(angle))

			
			box_displacement=[[0],[0],[0]]
			
			q=inv(R,np.array([p[0]+box_displacement[0][0],p[1]+box_displacement[1][0],p[2]]))

			jog_joint(robot,vel_ctrl,q,1)
			time.sleep(0.02)
			print("dropped")
			vacuum_inst.vacuum(robot_name+"::"+gripper_name,model_name,0)


			q=inv(R,np.array([p[0]+box_displacement[0][0],p[1]+box_displacement[1][0],p[2]+0.1]))
			jog_joint(robot,vel_ctrl,q,1)
		

		except:
			traceback.print_exc()
		return




	model_list=["box1"]+obj_namelists
	cognex_inst.update(model_list)

	destination=np.zeros(4)

	
	for obj in cognex_inst.objects:
		if obj.name in obj_namelists:
			p=np.dot(H,np.array([[obj.x],[obj.y],[1]]))
			p[2][0]=-0.03+height_offset							
			print("obj at: ",p)
			pick(p.reshape(3),robot,obj.name,obj.angle)

	for obj in cognex_inst.objects:

		if obj.name==slot_name: 

			destination[0]=obj.x
			destination[1]=obj.y
			destination[2]=obj.angle
			destination[3]=obj.box_idx

			p=np.dot(H,np.array([[destination[0]],[destination[1]],[1]]))
			p[2][0]=-0.1+height_offset	

			place(p.reshape(3),robot,model_list[-1],destination[3],obj.angle)

	




